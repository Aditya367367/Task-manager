For backend 

1> install all requirments 
pip install -r requirments.txt
2> run flask server 
python run.py

For front end 
ng serve --for starting the server 

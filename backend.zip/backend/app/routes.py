from flask import Blueprint, request, jsonify
from app.models import Task
from app import db
from datetime import datetime
from flask_cors import CORS
from dateutil import parser

api_blueprint = Blueprint('api', __name__)
CORS(api_blueprint)

@api_blueprint.route('/')
def home():
    return jsonify({"message": "Welcome to the Task Management API"})

# 1. Get all tasks with filters and sorting
@api_blueprint.route('/tasks', methods=['GET'])
def get_tasks():
    filters = request.args
    query = Task.query

    # Apply filters if present
    if 'status' in filters:
        query = query.filter_by(status=filters['status'])
    if 'entity_name' in filters:
        query = query.filter_by(entity_name=filters['entity_name'])
    if 'task_type' in filters:
        query = query.filter_by(task_type=filters['task_type'])
    if 'contact_person' in filters:
        query = query.filter_by(contact_person=filters['contact_person'])
    if 'date' in filters:
        date = datetime.strptime(filters['date'], '%Y-%m-%d')
        query = query.filter(Task.created_at >= date)
    
    # Sorting based on query params
    if 'sort_by' in filters:
        sort_field = filters['sort_by']
        query = query.order_by(getattr(Task, sort_field))

    tasks = query.all()
    return jsonify([task.to_dict() for task in tasks]), 200

# 2. Create a new task
@api_blueprint.route('/tasks', methods=['POST'])
def create_task():
    data = request.get_json()

    try:
        new_task = Task.from_dict(data)
        db.session.add(new_task)
        db.session.commit()
        return jsonify(new_task.to_dict()), 201
    except KeyError as e:
        return jsonify({'error': f'Missing required field: {e}'}), 400

# 3. Update task (edit task details)
@api_blueprint.route('/tasks/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    task = Task.query.get_or_404(task_id)
    data = request.get_json()  # Ensure this gets the JSON body

    if 'status' in data:
        task.status = data['status']
    if 'entity_name' in data:
        task.entity_name = data['entity_name']
    if 'task_type' in data:
        task.task_type = data['task_type']
    if 'task_time' in data:
        task.task_time = parser.isoparse(data['task_time'])
    if 'contact_person' in data:
        task.contact_person = data['contact_person']
    if 'note' in data:
        task.note = data['note']

    db.session.commit()
    return jsonify(task.to_dict()), 200

# 4. Delete a task
@api_blueprint.route('/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    task = Task.query.get_or_404(task_id)
    db.session.delete(task)
    db.session.commit()
    return jsonify({'message': 'Task deleted successfully'}), 200